@csrf
@method('DELETE')
<button type="submit"
        class="bg-red-700 hover:bg-red-800 rounded text-white flex justify-center items-center p-2 w-9 my-1 h-9"
>
    <i class="fas fa-trash-alt text-white"></i>
</button>
