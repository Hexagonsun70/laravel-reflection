<button class="bg-green-600 hover:bg-green-700 rounded text-white flex justify-center items-center p-2 my-1 mr-2 w-9 h-9">
    <i class="fas fa-eye"></i>
</button>
