
<td class="px-4 border-r border-dashed">
    {{ $slot }}
</td>
