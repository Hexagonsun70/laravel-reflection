<button class="bg-yellow-600 hover:bg-yellow-700 rounded text-white flex justify-center items-center p-2 my-1 mr-2 w-9 h-9">
    <i class="far fa-edit text-white"></i>
</button>
