<x-layout>
    <section class="flex flex-wrap justify-center login">

    </section>
</x-layout>
